# coding: utf-8
import os
import numpy as np
import pandas as pd
import spectral
import cv2
from sklearn.preprocessing import LabelEncoder
from skimage import data
from matplotlib import pyplot as plt
import get_glcm
import time
from PIL import Image

def main():
    pass


if __name__ == '__main__':
    
    main()
     
    start = time.time()

    folder_path = "D:\datass"

    
    for folder in os.listdir(folder_path):
        folder_dir = os.path.join(folder_path, folder)
        if os.path.isdir(folder_dir):
            for file in os.listdir(folder_dir):
                file_path = os.path.join(folder_dir, file)

                if file.endswith('.hdr'):
                    X.append(file_path)
                    Y.append(folder)


    data_df = pd.DataFrame({'file name': X, 'label': Y})

    
    encoder = LabelEncoder()
    encoded_labels = encoder.fit_transform(Y)
    data_df['encoded_labels'] = encoded_labels

    T_data = pd.DataFrame()
    for i in range(1, 129):
        for j in range(1, 5):
            column_name = f'Band{i}_{j}'
            
            T_data[column_name] = None
            T_data[column_name] = T_data[column_name].astype('object')

    data_df = pd.concat([data_df, T_data], axis=1)
  


   
    for i, img_path in enumerate(X):
        imgS = spectral.envi.open(img_path, img_path[:-4] + '.float')
        spectral_data = imgS.load()

        for j in range(spectral_data.shape[2]):
            
            band_data = spectral_data[:, :, j]

            nbit = 8  # gray levels
            mi, ma = 0, 255  # max gray and min gray
            slide_window = 7  # sliding window
            # step = [2, 4, 8, 16] # step
            # angle = [0, np.pi/4, np.pi/2, np.pi*3/4] # angle or direction
            step = [2]
            angle = [0, np.pi / 4, np.pi / 2, np.pi * 3 / 4]
            img = band_data
            img = np.uint8(255.0 * (img - np.min(img)) / (np.max(img) - np.min(img)))  # normalization
            #         print(img.shape)
            h, w = img.shape[0], img.shape[1]
            #         print(h,w)
            glcm = get_glcm.calcu_glcm(img, mi, ma, nbit, slide_window, step, angle)

            for n in range(glcm.shape[2]):
                for m in range(glcm.shape[3]):
                    glcm_cut = np.zeros((nbit, nbit, h, w), dtype=np.float32)
                    glcm_cut = glcm[:, :, n, m, :, :]
                    variance = get_glcm.calcu_glcm_variance(glcm_cut, nbit)
                    homogeneity = get_glcm.calcu_glcm_homogeneity(glcm_cut, nbit)
                    contrast = get_glcm.calcu_glcm_contrast(glcm_cut, nbit)
                    entropy = get_glcm.calcu_glcm_entropy(glcm_cut, nbit)
                    energy = get_glcm.calcu_glcm_energy(glcm_cut, nbit)

            attr1 = homogeneity.mean()
            attr2 = contrast.mean()
            attr3 = entropy.mean()
            attr4 = energy.mean()

          
            data_df.at[i, f'Band{j + 1}_1'] = attr1
            data_df.at[i, f'Band{j + 1}_2'] = attr2
            data_df.at[i, f'Band{j + 1}_3'] = attr3
            data_df.at[i, f'Band{j + 1}_4'] = attr4
        print("已获取纹理", i, end="\n")


    data_df.to_excel("D:\datasss\Texturedata.xlsx", index=False)




    end = time.time()
    print('Code run time:', end - start)
